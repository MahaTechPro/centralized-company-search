<?php ($title = 'Search'); ?>
<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
  <section class="space-y-6">
    <div class="bg-white p-6 rounded-2xl shadow-md border border-gray-200 transition hover:shadow-lg">
      <form action="<?php echo e(route('search.index')); ?>" method="GET" class="flex gap-2 animate-fade-in">
        <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Search companies by name..."
               class="flex-1 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 transition" />
        <button class="px-5 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 shadow hover:shadow-md transition">
          <i class="fas fa-search mr-1"></i> Search
        </button>
      </form>
      <p class="text-sm text-gray-500 mt-2">Searches both Singapore (SG) and Mexico (MX) databases.</p>
    </div>

    <?php if(!empty($q)): ?>
      <div class="bg-white p-6 rounded-2xl shadow-md border border-gray-200 animate-slide-up">
        <h2 class="text-lg font-semibold mb-4 flex items-center gap-2">
          <i class="fas fa-list text-blue-500"></i>
          Results for: <span class="font-normal"><?php echo e($q); ?></span>
        </h2>

        <?php if(count($results) === 0): ?>
          <div class="text-gray-500 py-6 text-center animate-fade-in">
            <i class="fas fa-search-minus text-3xl mb-2 text-gray-400"></i>
            <p>No results found.</p>
          </div>
        <?php else: ?>
          <ul class="divide-y divide-gray-200">
            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="py-4 flex items-center justify-between hover:bg-gray-50 px-2 rounded-lg transition transform hover:scale-[1.01]">
                <div class="animate-fade-in">
                  <div class="font-medium text-gray-800"><?php echo e($r['name']); ?></div>
                  <div class="text-sm text-gray-500 flex gap-2 mt-1">
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full border text-xs 
                      <?php echo e($r['country']==='SG' ? 'border-blue-300 text-blue-600 bg-blue-50' : 'border-amber-300 text-amber-600 bg-amber-50'); ?>">
                      <?php echo e($r['country']); ?>

                    </span>
                    <?php if(!empty($r['brand_name'])): ?><span><?php echo e($r['brand_name']); ?></span><?php endif; ?>
                    <?php if(!empty($r['address'])): ?><span>• <?php echo e($r['address']); ?></span><?php endif; ?>
                  </div>
                </div>
                <a href="<?php echo e($r['url']); ?>" class="text-blue-600 hover:underline flex items-center gap-1">
                  <i class="fas fa-arrow-right"></i> View
                </a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        <?php endif; ?>
      </div>
    <?php endif; ?>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\task\resources\views/search/index.blade.php ENDPATH**/ ?>