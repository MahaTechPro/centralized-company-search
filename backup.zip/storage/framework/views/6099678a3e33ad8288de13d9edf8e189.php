<?php ($title = $company['name'].' — '.$company['country']); ?>
<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
  <section class="space-y-6">
    <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
      <div class="flex items-center justify-between">
        <div>
          <h1 class="text-2xl font-semibold"><?php echo e($company['name']); ?></h1>
          <div class="text-sm text-gray-600 mt-1 flex gap-2">
            <span class="inline-flex items-center px-2 py-0.5 rounded-full border text-xs <?php echo e($company['country']==='SG' ? 'border-blue-300' : 'border-amber-300'); ?>"><?php echo e($company['country']); ?></span>
            <?php if(!empty($company['brand_name'])): ?><span>Brand: <?php echo e($company['brand_name']); ?></span><?php endif; ?>
            <?php if(!empty($company['state'])): ?><span>State: <?php echo e($company['state']); ?></span><?php endif; ?>
          </div>
          <?php if(!empty($company['address'])): ?>
            <div class="text-sm text-gray-500 mt-1"><?php echo e($company['address']); ?></div>
          <?php endif; ?>
        </div>
        <a href="<?php echo e(route('cart.index')); ?>" class="px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">View Cart</a>
      </div>
    </div>

    <div class="bg-white p-4 rounded-xl shadow-sm border border-gray-200">
      <h2 class="text-lg font-semibold mb-3">Available Reports</h2>

      <?php if(count($reports) === 0): ?>
        <p class="text-gray-500">No reports available.</p>
      <?php else: ?>
        <ul class="divide-y divide-gray-200">
          <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="py-3 flex items-center justify-between">
              <div>
                <div class="font-medium"><?php echo e($rep['name']); ?></div>
                <div class="text-sm text-gray-500"><?php echo e($rep['info']); ?></div>
                <div class="mt-1 font-semibold">Price: <?php echo e(number_format($rep['price'], 2)); ?></div>
              </div>
              <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="flex">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="company_name" value="<?php echo e($company['name']); ?>" />
                <input type="hidden" name="company_slug" value="<?php echo e($company['slug']); ?>" />
                <input type="hidden" name="country" value="<?php echo e($rep['country']); ?>" />
                <input type="hidden" name="report_id" value="<?php echo e($rep['id']); ?>" />
                <input type="hidden" name="report_name" value="<?php echo e($rep['name']); ?>" />
                <input type="hidden" name="price" value="<?php echo e($rep['price']); ?>" />
                <button class="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700">Add to Cart</button>
              </form>
            </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      <?php endif; ?>
    </div>
  </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\task\resources\views/companies/show.blade.php ENDPATH**/ ?>