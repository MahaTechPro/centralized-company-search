<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo e($title ?? 'Centralized Company Search'); ?></title>
  <!-- Tailwind via CDN for quick demo -->
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-900">
  <nav class="bg-white border-b border-gray-200">
    <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
      <a href="<?php echo e(route('search.index')); ?>" class="text-xl font-semibold">Centralized Search</a>
      <a href="<?php echo e(route('cart.index')); ?>" class="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100">
        <span>Cart</span>
      </a>
    </div>
  </nav>

  <main class="max-w-6xl mx-auto px-4 py-6">
    <?php if(session('ok')): ?>
      <div class="mb-4 p-3 rounded-lg bg-green-100 text-green-800"><?php echo e(session('ok')); ?></div>
    <?php endif; ?>
    <?php echo e($slot); ?>

  </main>

  <footer class="max-w-6xl mx-auto px-4 py-10 text-sm text-gray-500">
    <p>&copy; <?php echo e(date('Y')); ?> Centralized Company Search</p>
  </footer>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\task\resources\views/layouts/app.blade.php ENDPATH**/ ?>